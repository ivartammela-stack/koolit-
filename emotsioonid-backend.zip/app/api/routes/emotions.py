from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session
from app.api.deps import get_db, get_current_user, require_role
from app.schemas.emotion import EmotionCreate, EmotionRead
from app.crud.emotion import crud_emotion
from app.crud.student import crud_student
from app.models.emotion import EmotionEntry

router = APIRouter(prefix="/emotions", tags=["emotions"])

@router.post("/", response_model=EmotionRead, status_code=201)
def add_emotion(payload: EmotionCreate, db: Session = Depends(get_db), user=Depends(require_role("admin","teacher","counselor"))):
    # kontrolli, et õpilane eksisteerib
    if not crud_student.get(db, payload.student_id):
        raise HTTPException(status_code=404, detail="Student not found")
    obj = crud_emotion.create(db, {"student_id": payload.student_id, "mood": payload.mood, "note": payload.note, "created_by_user_id": user.id})
    return EmotionRead.model_validate(obj.__dict__)

@router.get("/by-student/{student_id}", response_model=List[EmotionRead])
def list_emotions(student_id: int, limit: int = Query(default=100, le=500), db: Session = Depends(get_db), user=Depends(require_role("admin","teacher","counselor"))):
    if not crud_student.get(db, student_id):
        raise HTTPException(status_code=404, detail="Student not found")
    items = crud_emotion.list_by_student(db, student_id=student_id, limit=limit)
    return [EmotionRead.model_validate(i.__dict__) for i in items]
